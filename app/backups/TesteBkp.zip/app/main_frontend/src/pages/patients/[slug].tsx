import PatientDetailBase from 'src/components/views/Patient/patient-detail';

export default function Patient(props: any) {
    return <PatientDetailBase />;
}
