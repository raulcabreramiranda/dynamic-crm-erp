import AdminProfileBase from 'src/components/views/AdminProfile/admin-profile';

export default function AdminProfile(props: any) {
    return <AdminProfileBase />;
}
