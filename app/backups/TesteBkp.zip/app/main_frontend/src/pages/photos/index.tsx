import PhotoBase from 'src/components/views/Photo/photo';

export default function Photo(props: any) {
    return <PhotoBase />;
}
