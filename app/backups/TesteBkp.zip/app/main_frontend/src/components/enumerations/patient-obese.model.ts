export enum PatientObese {
    SIM = 'SIM',
    NAO = 'NAO',
}
