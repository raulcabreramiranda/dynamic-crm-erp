export enum PatientLiminar {
    SIM = 'SIM',
    NAO = 'NAO',
}
