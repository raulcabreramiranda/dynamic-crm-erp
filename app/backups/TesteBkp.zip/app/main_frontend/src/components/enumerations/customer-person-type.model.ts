export enum CustomerPersonType {
    FISICA = 'FISICA',
    JURIDICA = 'JURIDICA',
}
