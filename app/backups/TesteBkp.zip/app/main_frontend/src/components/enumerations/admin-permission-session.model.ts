export enum AdminPermissionSession {
    PATIENT = 'PATIENT',
}
