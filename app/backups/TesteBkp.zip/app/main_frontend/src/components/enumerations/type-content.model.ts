export enum TypeContent {
    TEXT = 'TEXT',
    PRESENTATION = 'PRESENTATION',
    DEEPENING = 'DEEPENING',
}
