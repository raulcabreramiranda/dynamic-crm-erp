/**
 * The PatientAdId enumeration.
 */
export enum PatientAdId {
    AD = 'AD',
    ID = 'ID',
}
