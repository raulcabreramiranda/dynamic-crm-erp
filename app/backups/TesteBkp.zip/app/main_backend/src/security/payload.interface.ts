export interface Payload {
  id: number;
  username: string;
  userType? : string;
  whiteLabel? : number;
  clientId? : number;
  authorities?: any;
}
