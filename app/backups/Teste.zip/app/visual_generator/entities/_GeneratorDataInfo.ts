// @ts-ignore

const BASEDIR = process.cwd();

const generatorDataInfo = {
    initProjectPathFront: `${BASEDIR}/app/main_frontend/src`,
    initProjectPathBack: `${BASEDIR}/app/main_backend`,
}

export default generatorDataInfo
