export enum PatientPatientComplexity {
    BAIXA = 'BAIXA',
    MEDIA = 'MEDIA',
    ALTA = 'ALTA',
    VENTILACAOMECANICA = 'VENTILACAOMECANICA',
}
