import SubsidiaryBase from 'src/components/views/Subsidiary/subsidiary';

export default function Subsidiary(props: any) {
    return <SubsidiaryBase />;
}
