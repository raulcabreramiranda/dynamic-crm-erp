import ProfessionalBase from 'src/components/views/Professional/professional';

export default function Professional(props: any) {
    return <ProfessionalBase />;
}
