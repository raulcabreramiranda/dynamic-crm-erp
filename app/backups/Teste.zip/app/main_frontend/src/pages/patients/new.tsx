import PatientUpdateBase from 'src/components/views/Patient/patient-update';

export default function Patient(props: any) {
    return <PatientUpdateBase />;
}
