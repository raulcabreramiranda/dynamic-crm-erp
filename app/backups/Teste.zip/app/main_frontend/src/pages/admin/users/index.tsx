import AdminUserBase from 'src/components/views/AdminUser/admin-user';

export default function AdminUser(props: any) {
    return <AdminUserBase />;
}
