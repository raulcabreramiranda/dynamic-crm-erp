import AdminWhiteLabelBase from 'src/components/views/AdminWhiteLabel/admin-white-label';

export default function AdminWhiteLabel(props: any) {
    return <AdminWhiteLabelBase />;
}
