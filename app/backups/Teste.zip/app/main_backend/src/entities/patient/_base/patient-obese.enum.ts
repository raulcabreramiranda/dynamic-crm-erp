/**
 * The PatientObese enumeration.
 */
export enum PatientObese {
    SIM = 'SIM',
    NAO = 'NAO',
}
