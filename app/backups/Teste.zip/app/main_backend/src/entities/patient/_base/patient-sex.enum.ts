/**
 * The PatientSex enumeration.
 */
export enum PatientSex {
    MASCULINO = 'MASCULINO',
    FEMININO = 'FEMININO',
}
