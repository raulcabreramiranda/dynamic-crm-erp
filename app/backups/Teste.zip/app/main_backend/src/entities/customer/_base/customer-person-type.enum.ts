/**
 * The CustomerPersonType enumeration.
 */
export enum CustomerPersonType {
    FISICA = 'FISICA',
    JURIDICA = 'JURIDICA',
}
