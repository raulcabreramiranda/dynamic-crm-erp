import { EntityRepository, Repository } from 'typeorm';
// import { AdminUser as User } from '../entities/admin-user/_base/admin-user.entity';

// @EntityRepository(User)
export class UserRepository extends Repository<any> {}
