/**
 * The PhotoTypeContent enumeration.
 */
export enum PhotoTypeContent {
    TEXT = 'TEXT',
    PRESENTATION = 'PRESENTATION',
    DEEPENING = 'DEEPENING',
}
