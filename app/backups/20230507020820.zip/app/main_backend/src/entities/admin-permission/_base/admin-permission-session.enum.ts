/**
 * The AdminPermissionSession enumeration.
 */
export enum AdminPermissionSession {
    PATIENT = 'PATIENT',
}
