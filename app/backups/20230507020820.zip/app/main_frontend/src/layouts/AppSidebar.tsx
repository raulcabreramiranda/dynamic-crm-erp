import AppMenu from './AppMenu';

const AppSidebar = () => {
    return (
        <AppMenu></AppMenu>
    );
}

export default AppSidebar;