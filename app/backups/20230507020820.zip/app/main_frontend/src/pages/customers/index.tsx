import CustomerBase from 'src/components/views/Customer/customer';

export default function Customer(props: any) {
    return <CustomerBase />;
}
