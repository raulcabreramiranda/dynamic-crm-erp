import PatientBase from 'src/components/views/Patient/patient';

export default function Patient(props: any) {
    return <PatientBase />;
}
