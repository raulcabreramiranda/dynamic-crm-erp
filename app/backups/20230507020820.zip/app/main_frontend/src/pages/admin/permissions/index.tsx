import AdminPermissionBase from 'src/components/views/AdminPermission/admin-permission';

export default function AdminPermission(props: any) {
    return <AdminPermissionBase />;
}
