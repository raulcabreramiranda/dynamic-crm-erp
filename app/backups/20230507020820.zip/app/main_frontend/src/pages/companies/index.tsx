import CompanyBase from 'src/components/views/Company/company';

export default function Company(props: any) {
    return <CompanyBase />;
}
