export enum AdminPermissionMethod {
    LIST = 'LIST',
    SEE = 'SEE',
    EDIT = 'EDIT',
    REMOVE = 'REMOVE',
    CREATE = 'CREATE',
}
